from .cinema_api import api_cinema_bp

__all__ = ["api_cinema_bp"]