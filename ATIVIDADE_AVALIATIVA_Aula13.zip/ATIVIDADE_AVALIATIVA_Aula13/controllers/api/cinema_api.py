from flask import Blueprint, jsonify, request
from datetime import datetime
from models import Filme, Sessao, db

api_cinema_bp = Blueprint("api_cinema", __name__, url_prefix="/api")

# --- ROTAS PARA FILMES ---
@api_cinema_bp.route("/filmes", methods=["GET"])
def listar_filmes():
    filmes = Filme.listar()
    return jsonify([f.para_dict() for f in filmes])

# --- ROTAS PARA SESSÕES ---
@api_cinema_bp.route("/sessoes", methods=["GET"])
def listar_sessoes():
    sessoes = Sessao.listar_com_detalhes()
    return jsonify([s.para_dict() for s in sessoes])

@api_cinema_bp.route("/sessoes/<int:sessao_id>", methods=["GET"])
def detalhe_sessao(sessao_id):
    sessao = db.session.get(Sessao, sessao_id)
    if not sessao:
        return jsonify({"erro": "Sessão não encontrada"}), 404
    return jsonify(sessao.para_dict())

@api_cinema_bp.route("/sessoes", methods=["POST"])
def criar_sessao():
    dados = request.get_json()

    if not dados:
        return jsonify({"erro": "Envie JSON no body"}), 400

    try:
        data_hora_obj = datetime.fromisoformat(dados["data_hora"])
        
        nova_sessao = Sessao(
            filme_id=int(dados["filme_id"]),
            sala_id=int(dados["sala_id"]),
            data_hora=data_hora_obj,
            preco=float(dados["preco"])
        )
    except (KeyError, ValueError, TypeError):
        return jsonify({"erro": "Campos obrigatórios inválidos: filme_id, sala_id, data_hora, preco"}), 400

    db.session.add(nova_sessao)
    db.session.commit()

    return jsonify(nova_sessao.para_dict()), 201

@api_cinema_bp.route("/sessoes/<int:sessao_id>", methods=["DELETE"])
def excluir_sessao(sessao_id):
    sessao = db.session.get(Sessao, sessao_id)
    if not sessao:
        return jsonify({"erro": "Sessão não encontrada"}), 404

    db.session.delete(sessao)
    db.session.commit()
    return "", 204