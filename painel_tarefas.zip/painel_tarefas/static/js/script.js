const btnDarkMode = document.getElementById('btnDarkMode');

if (localStorage.getItem('theme') === 'dark') {
    document.body.classList.add('bg-dark', 'text-light');
}

if(btnDarkMode) {
    btnDarkMode.addEventListener('click', () => {
        document.body.classList.toggle('bg-dark');
        document.body.classList.toggle('text-light');
        
        if (document.body.classList.contains('bg-dark')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
    });
}

const filtroStatus = document.getElementById('filtroStatus');
const containerTarefas = document.getElementById('containerTarefas');

if (filtroStatus) {
    filtroStatus.addEventListener('change', (e) => {
        const statusSelecionado = e.target.value;
        
        fetch(`/api/tarefas?status=${statusSelecionado}`)
            .then(res => res.json())
            .then(tarefas => {
                containerTarefas.innerHTML = '';
                
                tarefas.forEach(tarefa => {
                    let corClasse = 'bg-success';
                    let textoClasse = 'text-white';
                    if (tarefa.status === 'Pendente') { corClasse = 'bg-warning'; textoClasse = 'text-dark'; }
                    if (tarefa.status === 'Em andamento') { corClasse = 'bg-primary'; }
                    
                    containerTarefas.innerHTML += `
                        <div class="col-md-4 mb-3">
                            <div class="card ${corClasse} ${textoClasse}">
                                <div class="card-body">
                                    <h5 class="card-title">${tarefa.titulo}</h5>
                                    <p class="card-text">${tarefa.descricao}</p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="badge bg-light text-dark">${tarefa.status}</span>
                                        <div>
                                            <a href="/editar/${tarefa.id}" class="text-white me-2"><i class="bi bi-pencil-square"></i></a>
                                            <a href="/excluir/${tarefa.id}" class="text-white text-danger" onclick="return confirm('Tem certeza?')"><i class="bi bi-trash-fill"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                });
            });
    });
}