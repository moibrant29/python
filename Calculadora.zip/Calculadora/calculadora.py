import math
from flask import render_template, request

def calcular():
    try:
        num1 = float(request.form["num1"])
    except ValueError:
        return render_template("calculadora.html", etapas="Erro ao ler os dados", resultados="Número 1 inválido.")

    operacao = request.form.get("operacao")

    if operacao == "sqrt":
        if num1 < 0:
            resultado = "Erro: número negativo"
            etapas = f"Não existe raiz real de {num1}."
        else:
            resultado = round(math.sqrt(num1), 4)
            etapas = f"√{num1} = {resultado}"
            
    else:
        num2_valor = request.form.get("num2", "").strip()
        if not num2_valor:
            return render_template(
                "calculadora.html",
                etapas="Informe o segundo número para esta operação.",
                resultados="",
            )
            
        try:
            num2 = float(num2_valor)
        except ValueError:
            return render_template("calculadora.html", etapas="Erro", resultados="Número 2 inválido.")

        if operacao == "+":
            resultado = num1 + num2
            etapas = f"{num1} + {num2} = {resultado}"
            
        elif operacao == "-":
            resultado = num1 - num2
            etapas = f"{num1} - {num2} = {resultado}"
            
        elif operacao == "*":
            resultado = num1 * num2
            etapas = f"{num1} * {num2} = {resultado}"
            
        elif operacao == "/":
            if num2 == 0:
                resultado = "Erro: Divisão por zero"
                etapas = "A matemática não permite divisão por zero."
            else:
                resultado = num1 / num2
                etapas = f"{num1} ÷ {num2} = {resultado}"
                
        elif operacao == "**":
            resultado = num1 ** num2
            etapas = f"{num1} elevado a {num2} = {resultado}"
            
        elif operacao == "log":
            if num1 <= 0:
                resultado = "Erro: Logaritmando inválido"
                etapas = "O valor para o logaritmo deve ser maior que zero."
            elif num2 <= 0 or num2 == 1:
                resultado = "Erro: Base inválida"
                etapas = "A base do logaritmo deve ser maior que zero e diferente de 1."
            else:
                resultado = round(math.log(num1, num2), 4)
                etapas = f"Logaritmo de {num1} na base {num2} = {resultado}"
                
        else:
            resultado = "Erro"
            etapas = "Operação inválida."

    return render_template("calculadora.html", etapas=etapas, resultados=resultado)