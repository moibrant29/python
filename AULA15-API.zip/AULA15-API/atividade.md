# Atividade Aula 15 - Testes de API (Livros)

## 1. Inserção de 3 novos livros (POST)

**Comandos executados no PowerShell:**
`Invoke-RestMethod http://127.0.0.1:5000/api/livros -Method POST -ContentType "application/json" -Body '{"titulo":"O Senhor dos Anéis", "autor":"J.R.R. Tolkien", "ano":1954}'`

`Invoke-RestMethod http://127.0.0.1:5000/api/livros -Method POST -ContentType "application/json" -Body '{"titulo":"1984", "autor":"George Orwell", "ano":1949}'`

`Invoke-RestMethod http://127.0.0.1:5000/api/livros -Method POST -ContentType "application/json" -Body '{"titulo":"Dom Quixote", "autor":"Miguel de Cervantes", "ano":1605}'`

## 2. Atualizando a lista (PUT no índice 1)

**Comando executado:**
`Invoke-RestMethod http://127.0.0.1:5000/api/livros/1 -Method PUT -ContentType "application/json" -Body '{"titulo":"Cotemig","autor":"3A1","ano":2026}'`

**Resultado obtido:**
ano          : 2026
autor        : 3A1
data_criacao : 2026-07-27 09:34:57.866680
id           : 1
titulo       : Cotemig

## 3. Consultando os Livros após o PUT (GET)

**Comando executado:**
`Invoke-RestMethod http://127.0.0.1:5000/api/livros`

**Resultado obtido:**
ano          : 2026
autor        : 3A1
id           : 1
titulo       : Cotemig

ano          : 1949
autor        : George Orwell
id           : 2
titulo       : 1984

ano          : 1605
autor        : Miguel de Cervantes
id           : 3
titulo       : Dom Quixote

## 4. Deletando os índices 1, 2 e 3 (DELETE)

**Comandos executados:**
`Invoke-RestMethod http://127.0.0.1:5000/api/livros/1 -Method DELETE`
`Invoke-RestMethod http://127.0.0.1:5000/api/livros/2 -Method DELETE`
`Invoke-RestMethod http://127.0.0.1:5000/api/livros/3 -Method DELETE`

## 5. Consultando a lista após as exclusões (GET)

**Comando executado:**
`Invoke-RestMethod http://127.0.0.1:5000/api/livros`

**Resultado obtido:**
[]