import soma
import subtrair
import multiplicar
import divisao
import potencia
import raizquadrada
import dolar

def calculadora():
    print("=== Calculadora Científica ===")
    
    a = float(input("Digite o número A: "))
    b = float(input("Digite o número B: "))

    print("\n--- Resultados ---")
    print("Soma:            ", soma.somar(a, b))
    print("Subtração:       ", subtrair.subtrair(a, b))
    print("Multiplicação:   ", multiplicar.multiplicar(a, b))
    print("Divisão:         ", divisao.dividir(a, b))
    print("Potência (A^B):  ", potencia.potencia(a, b))
    print("Raiz de A:       ", raizquadrada.raiz_quadrada(a))

    print("\n--- Conversão ---")
    
    valor_real = float(input("Digite um valor em reais para converter: "))
    
    cotacao = dolar.cotacao_dolar()
    
    if cotacao != 0:
        convertido = valor_real / cotacao
        print("Valor em dólar:", convertido)