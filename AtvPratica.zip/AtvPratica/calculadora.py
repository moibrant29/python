from flask import Flask, render_template, request

import soma
import subtrair
import multiplicar
import divisao
import potencia
import raizquadrada
import dolar

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('calculadora.html')

@app.route('/calcular', methods=['POST'])
def calcular():
    try:
        a_str = request.form.get('numA', '')
        b_str = request.form.get('numB', '')
        operacao = request.form.get('operacao')
        valor_real_str = request.form.get('valor_real', '')

        a = float(a_str) if a_str else 0.0
        b = float(b_str) if b_str else 0.0
        
        etapas = ""
        
        if operacao == '+':
            resultado = soma.somar(a, b)
            etapas = f"{a} + {b} = {resultado}"
        elif operacao == '-':
            resultado = subtrair.subtrair(a, b)
            etapas = f"{a} - {b} = {resultado}"
        elif operacao == '*':
            resultado = multiplicar.multiplicar(a, b)
            etapas = f"{a} * {b} = {resultado}"
        elif operacao == '/':
            resultado = divisao.dividir(a, b)
            etapas = f"{a} / {b} = {resultado}"
        elif operacao == '^':
            resultado = potencia.potencia(a, b)
            etapas = f"{a} ^ {b} = {resultado}"
        elif operacao == 'raiz':
            resultado = raizquadrada.raiz_quadrada(a)
            etapas = f"Raiz de {a} = {resultado}"

        msg_dolar = ""
        if valor_real_str:
            valor_real = float(valor_real_str)
            cotacao = dolar.cotacao_dolar()
            if cotacao != 0:
                convertido = valor_real / cotacao
                msg_dolar = f"R$ {valor_real:.2f} equivalem a US$ {convertido:.2f} (Cotação atual: R$ {cotacao:.2f})"
            else:
                msg_dolar = "Erro ao buscar a cotação na API."

        return render_template('calculadora.html', etapas=etapas, msg_dolar=msg_dolar)

    except ValueError:
        return render_template('calculadora.html', erro="Entrada inválida. Digite apenas números.")

if __name__ == '__main__':
    app.run(debug=True)