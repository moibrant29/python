from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import requests
from database import get_db_connection

app = Flask(__name__)
app.secret_key = 'SUA_SECRET_KEY_SUPER_SECRETA' 


@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        senha = request.form['senha']
        
        senha_hash = generate_password_hash(senha)
        
        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)', 
                         (nome, email, senha_hash))
            conn.commit()
            return redirect(url_for('login'))
        except:
            return "Erro: Email já cadastrado."
        finally:
            conn.close()
            
    return render_template('registro.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        
        conn = get_db_connection()
        usuario = conn.execute('SELECT * FROM usuarios WHERE email = ?', (email,)).fetchone()
        conn.close()
        
        if usuario and check_password_hash(usuario['senha'], senha):
            session['usuario_id'] = usuario['id']
            session['usuario_nome'] = usuario['nome']
            return redirect(url_for('dashboard'))
            
        return "Credenciais inválidas."
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))



@app.route('/dashboard')
def dashboard():
    if 'usuario_id' not in session:
        return redirect(url_for('login'))
        
    conselho = "Mantenha o foco!"
    try:
        response = requests.get('https://api.adviceslip.com/advice')
        if response.status_code == 200:
            conselho = response.json()['slip']['advice']
    except:
        pass

    conn = get_db_connection()
    tarefas = conn.execute('SELECT * FROM tarefas WHERE usuario_id = ?', (session['usuario_id'],)).fetchall()
    conn.close()
    
    return render_template('dashboard.html', tarefas=tarefas, conselho=conselho)

@app.route('/nova_tarefa', methods=['GET', 'POST'])
def nova_tarefa():
    if 'usuario_id' not in session: return redirect(url_for('login'))
    
    if request.method == 'POST':
        titulo = request.form['titulo']
        descricao = request.form['descricao']
        status = request.form['status']
        
        conn = get_db_connection()
        conn.execute('INSERT INTO tarefas (titulo, descricao, status, usuario_id) VALUES (?, ?, ?, ?)',
                     (titulo, descricao, status, session['usuario_id']))
        conn.commit()
        conn.close()
        return redirect(url_for('dashboard'))
        
    return render_template('nova_tarefa.html')

@app.route('/editar/<int:id>', methods=['GET', 'POST'])
def editar(id):
    if 'usuario_id' not in session: return redirect(url_for('login'))
    
    conn = get_db_connection()
    tarefa = conn.execute('SELECT * FROM tarefas WHERE id = ? AND usuario_id = ?', (id, session['usuario_id'])).fetchone()
    
    if request.method == 'POST':
        titulo = request.form['titulo']
        descricao = request.form['descricao']
        status = request.form['status']
        
        conn.execute('UPDATE tarefas SET titulo = ?, descricao = ?, status = ? WHERE id = ?',
                     (titulo, descricao, status, id))
        conn.commit()
        conn.close()
        return redirect(url_for('dashboard'))
        
    conn.close()
    return render_template('editar_tarefa.html', tarefa=tarefa)

@app.route('/excluir/<int:id>')
def excluir(id):
    if 'usuario_id' not in session: return redirect(url_for('login'))
    
    conn = get_db_connection()
    conn.execute('DELETE FROM tarefas WHERE id = ? AND usuario_id = ?', (id, session['usuario_id']))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))



@app.route('/api/tarefas')
def api_tarefas():
    if 'usuario_id' not in session: return jsonify([])
    status_filtro = request.args.get('status')
    
    conn = get_db_connection()
    if status_filtro and status_filtro != 'Todas':
        tarefas = conn.execute('SELECT * FROM tarefas WHERE usuario_id = ? AND status = ?', 
                               (session['usuario_id'], status_filtro)).fetchall()
    else:
        tarefas = conn.execute('SELECT * FROM tarefas WHERE usuario_id = ?', (session['usuario_id'],)).fetchall()
    conn.close()
    
    return jsonify([dict(t) for t in tarefas])

@app.route('/progresso_dados')
def progresso_dados():
    if 'usuario_id' not in session: return jsonify({})
    
    conn = get_db_connection()
    dados = conn.execute('''
        SELECT status, COUNT(*) as qtd 
        FROM tarefas 
        WHERE usuario_id = ? 
        GROUP BY status
    ''', (session['usuario_id'],)).fetchall()
    conn.close()
    
    return jsonify({row['status']: row['qtd'] for row in dados})

@app.route('/progresso')
def progresso():
    if 'usuario_id' not in session: return redirect(url_for('login'))
    return render_template('progresso.html')

if __name__ == '__main__':
    app.run(debug=True) 