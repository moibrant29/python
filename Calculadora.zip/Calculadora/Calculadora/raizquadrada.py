def raiz_quadrada(a):
    if a < 0:
        return "Erro: não existe raiz de número negativo"
    return a ** 0.5